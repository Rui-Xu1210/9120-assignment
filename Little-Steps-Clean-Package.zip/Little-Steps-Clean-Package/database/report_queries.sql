-- Read-only query examples for Report Section 4.2.
-- These examples use the fictional demonstration child C00001 (Emma Demo).-- Run against the initialized 9120assignment_demo database.

-- 1. Join the child, schedule identity, schedule details and vaccine tables
--    to display a child's planned and completed doses.
SELECT
    c.child_id,
    c.name AS child_name,
    v.vaccine_name,
    si.dose_number,
    s.scheduled_date,
    s.status
FROM Child AS c
JOIN Vaccine_schedule_id AS si USING (child_id)
JOIN Vaccine_schedule AS s USING (schedule_id)
JOIN Vaccine AS v USING (vaccine_id)
WHERE c.child_id = 'C00001'
ORDER BY s.scheduled_date, v.vaccine_name
LIMIT 8;

-- 2. Join vaccination records to child and vaccine details to show history.
SELECT
    c.child_id,
    c.name AS child_name,
    v.vaccine_name,
    r.dose_number,
    r.vaccination_date,
    r.provider
FROM Vaccine_Record AS r
JOIN Child AS c USING (child_id)
JOIN Vaccine AS v USING (vaccine_id)
WHERE c.child_id = 'C00001'
ORDER BY r.vaccination_date;

-- 3. Aggregate planned doses by child and status.
SELECT
    c.child_id,
    c.name AS child_name,
    COUNT(*) AS total_doses,
    COUNT(*) FILTER (WHERE s.status = 'completed') AS completed_doses,
    COUNT(*) FILTER (WHERE s.status = 'pending') AS pending_doses
FROM Child AS c
JOIN Vaccine_schedule_id AS si USING (child_id)
JOIN Vaccine_schedule AS s USING (schedule_id)
GROUP BY c.child_id, c.name
ORDER BY c.child_id;

-- 4. Derive overdue doses: the planned date has passed, the schedule is still
--    pending, and no matching vaccination record exists.
SELECT
    c.child_id,
    c.name AS child_name,
    v.vaccine_name,
    si.dose_number,
    s.scheduled_date
FROM Child AS c
JOIN Vaccine_schedule_id AS si USING (child_id)
JOIN Vaccine_schedule AS s USING (schedule_id)
JOIN Vaccine AS v USING (vaccine_id)
WHERE c.child_id = 'C00001'
  AND s.scheduled_date < CURRENT_DATE
  AND s.status = 'pending'
  AND NOT EXISTS (
      SELECT 1
      FROM Vaccine_Record AS r
      WHERE r.child_id = si.child_id
        AND r.vaccine_id = si.vaccine_id
        AND r.dose_number = si.dose_number
  )
ORDER BY s.scheduled_date, v.vaccine_name;

-- 5. Group vaccine-disease pairs into a readable vaccine summary.
SELECT
    v.vaccine_name,
    STRING_AGG(pd.disease_name, ', ' ORDER BY pd.disease_name) AS diseases_prevented
FROM Vaccine AS v
JOIN Prevented_Disease AS pd USING (vaccine_id)
WHERE v.vaccine_name = 'Infanrix hexa'
GROUP BY v.vaccine_id, v.vaccine_name;
