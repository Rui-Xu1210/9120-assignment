-- Fictional demonstration rows for a fresh database initialized with
-- sql_code.sql followed by Insert_dataset.sql.
-- Run once only. Do not run against an already populated database.

BEGIN;

DO $$
DECLARE
    alex_id CHAR(6);
    jones_id CHAR(6);
    emma_id CHAR(6);
    tom_id CHAR(6);
    lily_id CHAR(6);
    engerix_id CHAR(6);
    prevenar_id CHAR(6);
BEGIN
    INSERT INTO Parent (name)
    VALUES ('Alex Demo')
    RETURNING parent_id INTO alex_id;

    INSERT INTO Parent (name)
    VALUES ('Jones Demo')
    RETURNING parent_id INTO jones_id;

    INSERT INTO Child (name, date_of_birth, parent_id)
    VALUES ('Emma Demo', DATE '2026-04-20', alex_id)
    RETURNING child_id INTO emma_id;

    INSERT INTO Child (name, date_of_birth, parent_id)
    VALUES ('Tom', DATE '2019-07-20', alex_id)
    RETURNING child_id INTO tom_id;

    INSERT INTO Child (name, date_of_birth, parent_id)
    VALUES ('Lily Demo', DATE '2017-03-02', jones_id)
    RETURNING child_id INTO lily_id;

    SELECT vaccine_id INTO STRICT engerix_id
    FROM Vaccine
    WHERE vaccine_name = 'Engerix B';

    SELECT vaccine_id INTO STRICT prevenar_id
    FROM Vaccine
    WHERE vaccine_name = 'Prevenar 20';

    INSERT INTO Vaccine_Record
        (child_id, vaccine_id, dose_number, vaccination_date, provider)
    VALUES
        (emma_id, engerix_id, 1, TIMESTAMP '2026-04-20 12:00:00', 'Demo Family Clinic'),
        (tom_id, engerix_id, 1, TIMESTAMP '2019-07-20 12:00:00', 'Hospital 1'),
        (tom_id, prevenar_id, 1, TIMESTAMP '2019-09-20 12:00:00', NULL);
END;
$$;

COMMIT;
