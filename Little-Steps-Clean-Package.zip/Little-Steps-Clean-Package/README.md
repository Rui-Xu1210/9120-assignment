# Little Steps — Clean Coursework Package

This package contains the four SQL files, the Python API and responsive web interface, and the Xcode project used to build the iPhone and Mac apps. 

## Folder structure

```text
Little-Steps-Clean-Package/
├── database/
│   ├── sql_code.sql
│   ├── Insert_dataset.sql
│   ├── report_demo_data.sql
│   └── report_queries.sql
├── backend/
│   ├── app/                 Python API
│   ├── frontend/            Browser preview served by the API
│   ├── scripts/serve.py
│   ├── requirements.txt
│   ├── requirements-lock.txt
│   ├── .env.example
│   └── start.command
└── iphone/apple/
    ├── LittleSteps.xcodeproj/
    ├── Sources/
    ├── Assets.xcassets/
    └── Info.plist
```

## Run on the presentation Mac

The Mac app and Python API run on the same computer and use `http://127.0.0.1:8000`. This avoids the Wi-Fi connection needed by an iPhone. PostgreSQL still needs to be running locally.

1. Complete the database setup and API configuration below once.
2. Start PostgreSQL.
3. Double-click `backend/start.command` and leave its Terminal window open. The first run installs the Python packages and creates `backend/.env` from `.env.example`; fill in the local PostgreSQL details in `.env` if prompted, then run `start.command` again.
4. Open `iphone/apple/LittleSteps.xcodeproj` in Xcode, select **My Mac** as the run destination, and press **Run**. The Mac app opens the same Schedule, History, Reminders and Family pages as the iPhone app.

If the app cannot connect, check that the Python server is still running in Terminal and that its address is `http://127.0.0.1:8000`. Use the app's **Try again** button after restarting the server.

## Build and run on a new Mac and iPhone

The Mac runs PostgreSQL and the Python API. The iPhone app connects to that API over the same Wi-Fi network. Xcode must be installed on the Mac; Xcode is not installed on the iPhone.

### 1. Create a clean PostgreSQL database

1. Start PostgreSQL and open pgAdmin.
2. Create a new, empty database named **`9120assignment_demo`**. The API is configured to refuse other database names.
3. Open that database's Query Tool. Run these SQL files in order:
   - `database/sql_code.sql`
   - `database/Insert_dataset.sql`
   - `database/report_demo_data.sql` (optional; adds fictional families and records for the demo)
4. `database/report_queries.sql` contains report queries; it is not part of database setup.

These setup files are for a fresh, empty database. Do not rerun them over an existing populated database. If you omit the optional demo data, add a parent and child through the app.

### 2. Configure and start the Python API

1. In `backend`, copy `.env.example` to `.env`. Fill in the PostgreSQL host, port, username and password for the local server. Keep `DB_NAME=9120assignment_demo` and `APP_PORT=8000`. Never submit or share `.env`.
2. Open Terminal in the `backend` folder and run:

```bash
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -r requirements.txt
python3 scripts/serve.py
```

Keep this Terminal window running. On the Mac, open `http://127.0.0.1:8000/` for the browser preview.

### 3. Build and install the iPhone app

1. Open `iphone/apple/LittleSteps.xcodeproj` in Xcode.
2. Select the **LittleSteps** target and an iPhone run destination.
3. In **Signing & Capabilities**, enable automatic signing and select your own Apple development Team. If Xcode requests it, set a unique Bundle Identifier.
4. Connect the iPhone, trust the Mac, and follow any Developer Mode prompt. Press **Run** in Xcode.
5. Keep the Mac and iPhone on the same trusted Wi-Fi network. In Little Steps' server settings, enter the Mac's Wi-Fi address, for example `http://192.168.1.10:8000`. Do not use `localhost` on the iPhone. The address is saved on the iPhone; if it changes, reopen the app and choose **Server settings** on the connection screen.
6. Allow Local Network access if iOS asks.

A physical-device build must be signed on that Mac using its owner's Apple development Team. This package does not contain an IPA, certificates, provisioning profiles, or Apple credentials.

## Notes

- The app uses fictional coursework data. The sample schedule is not medical advice.
- The local API has no login and uses HTTP. Use a trusted local network only.
- Reminder records appear in the app; this project does not send push notifications, emails, or text messages.
- The Mac target uses the same web interface as iPhone and connects to the Python API on `127.0.0.1` by default.
